from concurrent import futures

import grpc
import compiled_files.db_pb2 as db_pb2
import compiled_files.db_pb2_grpc as db_pb2_grpc

from core.db_mgmt import DBManager

class LibraryManagementService(db_pb2_grpc.LibraryManagementServicer):
    def __init__(self):
        self.count = 0

    def check_connection(self, request, context):
        print("check_connection request made:")
        print(request)

        success_message = db_pb2.SuccessMessage()
        try:
            dbobj = DBManager()
            conn = dbobj.connect()
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                        CREATE TABLE IF NOT EXISTS authors (
                            id SERIAL PRIMARY KEY,
                            first_name TEXT NOT NULL,
                            last_name TEXT NOT NULL
                        )
                    """
                )
            conn.commit()
            print("Table Authors created successfully.")
        except Exception as e:
            print(f"Database connection failed")
            print(f"aditya - {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details('Database connection failed!')
            # raise
            success_message.message = "DB Connection failed"
            return success_message

        
        success_message.message = "DB Connection successful"
        return success_message
    
    def insert_books(self, request, context):
        print("Insert books request mande.")
        print(request)

        success_message = db_pb2.SuccessMessage()
        success_message.message = "Insert books not implemented yet"

        return success_message

    def insert_authors(self, request, context):
        print("Insert Authors request mande.")
        print(type(request))
        success_message = db_pb2.SuccessMessage()
        try:
            DBManager().insert_authors(request)
            success_message = "Author inserted successfully"
        except Exception as e:
            print(f"Exception in inserting author: {e}")        
            success_message.message = "Insert authors failed"

        return success_message
    
    def insert_member(self, request, context):
        print("Insert Members request mande.")
        print(request)

        success_message = db_pb2.SuccessMessage()
        success_message.message = "Insert members not implemented yet"

        return success_message
    
    def fetch_all_authors(self, request, context):
        # db = DBManager()
        # result = db.fetch_all_authors()
        # return result
        return DBManager().fetch_all_authors()

def serve():
    print("Strating Library Management Server")
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    db_pb2_grpc.add_LibraryManagementServicer_to_server(LibraryManagementService(), server)
    server.add_insecure_port("localhost:50051")
    server.start()
    print("Library Management Server started on port 50051")
    server.wait_for_termination()


if __name__ == "__main__":
    serve()

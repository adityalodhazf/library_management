import compiled_files.db_pb2 as db_pb2
import compiled_files.db_pb2_grpc as db_pb2_grpc

from datetime import datetime
from google.protobuf.empty_pb2 import Empty
from google.protobuf.timestamp_pb2 import Timestamp

import grpc


def build_single_book_request():
    publication_date = Timestamp()
    publication_date.FromDatetime(datetime(2020, 1, 15, 10, 0, 0))

    book = db_pb2.BookRecord(
        title="The Hobbit",
        isbn="9780547928227",
        genere="Fantasy",
        publisher="Houghton Mifflin",
        publication_date=publication_date,
        fine_per_day=50,
    )
    return db_pb2.Books(books=[book])


def run():
    print("Starting Library Management Test Client")
    with grpc.insecure_channel("localhost:50051") as channel:
        stub = db_pb2_grpc.LibraryManagementStub(channel)
        print("1. check_connection - Unary")
        print("2. insert_books (single sample book)")
        print("3. Exit")
        print("4. Fetch all Authors")
        print("5. Insert Authors")

        rpc_call = int(input("Which rpc call do you want to make (1-3): "))

        if rpc_call == 1:
            try:
                success_message = stub.check_connection(Empty())
                print(f"Response from server: {success_message}")
            except Exception as e:
                print(f"DB Connection failed")
        elif rpc_call == 2:
            publication_date = Timestamp()
            publication_date.FromDatetime(datetime(2020, 1, 15, 10, 0, 0))

            book = db_pb2.BookRecord(
                title="The Hobbit",
                isbn="9780547928227",
                genere="Fantasy",
                publisher="Houghton Mifflin",
                publication_date=publication_date,
                fine_per_day=50,
            )
            request = db_pb2.Books(books=[book])
            # request = build_single_book_request()
            print(f"Sending payload: {request}")
            success_message = stub.insert_books(request)
            print(f"Response from server: {success_message}")
        elif rpc_call == 3:
            print("Exiting...")
            exit()
        elif rpc_call == 4:
            result = stub.fetch_all_authors(Empty())
            for author in result.authors:
                print(
                    f"first_name: {author.first_name}"
                    f"last_name: {author.last_name}"
                )
        elif rpc_call == 5:
            print("Inserting author")
            first_name = input("First Name: ")
            last_name = input("Last name: ")

            authors = []
            author = db_pb2.AuthorRecord(
                first_name = first_name,
                last_name = last_name
            )
            authors.append(author)
            success_message = stub.insert_authors(db_pb2.Authors(authors=authors))
            print(success_message)
        else:
            print("Invalid input. Please enter a number between 1 and 3.")


if __name__ == "__main__":
    while True:
        run()

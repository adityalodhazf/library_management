import os
import sys
import threading
from pathlib import Path

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, scoped_session

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent.parent
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from compiled_files import db_pb2 as db_pb2

load_dotenv()

class DBManager():
    _instance = None
    _lock = threading.Lock() #ensured thread safety during initialization
    _database_url = os.getenv("DATABASE_URL")

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):#, database_url: str):
        if self._initialized:
            return

        # 1. Create a single engine with a built-in QueuePool
        self.engine = create_engine(
            self._database_url,
            pool_size=10,         # Maximum persistent connections
            max_overflow=20,      # Transient connections allowed under heavy load
            pool_recycle=3600,    # Recycle connections after 1 hour
            pool_pre_ping=True    # Check connection health before checkout
        )
        
        # 2. Bind a thread-local scoped session factory
        self.session_factory = scoped_session(
            sessionmaker(bind=self.engine)
        )
        self._initialized = True

    def get_session(self):
        """Returns a thread-safe scoped session."""
        return self.session_factory()
    
    def fetch_all_authors(self):
        """
        returns all authors from the table
        """
        print("fetching all authors")
        session = self.get_session()
        query = "SELECT first_name, last_name FROM authors;"
        rows = session.execute(text(query)).fetchall()
        authors = []
        for row in rows:
            authors.append(
                db_pb2.AuthorRecord(
                    first_name=row.first_name,
                    last_name=row.last_name
                )
            )
        return db_pb2.Authors(authors=authors)
    
    def insert_author(self, author: db_pb2.AuthorRecord):
        """
        inserts author into db
        """
        print("Inserting author into db")
        session = self.get_session()
        query = (
            f"INSERT INTO authors (first_name, last_name)"
            f" VALUES ('{author.first_name}', '{author.last_name}');"
        )

        print(f"aditya - insert author query = {query}")
        session.execute(text(query))
        session.commit()
        
    
    def insert_authors(self, authors:db_pb2.Authors):
        print(authors.authors)
        for author in authors.authors:
            self.insert_author(author=author)
    

def test():
    # --- Usage Example ---
    # DATABASE_URL = "postgresql://admin:password12345@localhost:5432/library_mgmt"
    DATABASE_URL = os.getenv("DATABASE_URL")

    # Both calls yield the exact same instance and share the same pool
    db1 = DBManager()
    # db2 = DBManager(DATABASE_URL)
    # print(db1 is db2)  # True

    # Execute queries safely using context managers
    session = db1.get_session()
    try:
        # result = session.execute(text("SELECT * FROM authors;"))
        # rows = result.fetchall()
        rows = db1.fetch_all_authors()
        if not rows:
            print("Table is empty.")
        else:
            # for row in rows:
                print(rows)
        session.commit()
    except Exception as e:
        print(f"Query execution failed: {e}")
    finally:
        db1.session_factory.remove()  # Clean up and return connection to pool


if __name__ == "__main__":
    print("Test function for sqlalchemy connection pool")
    test()